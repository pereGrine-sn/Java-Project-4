//Samuel Noel
//01/28/23
class Main {
  public static void main(String[] args){
    System.out.print("The first 50 prime numbers are: ");
    int count = 0;
    int number = 2;
while (count < 50){ //Create a loop that runs until the count reaches 50 check
  boolean numPrime = true;//start by assuming the number is prime check
  for(int i = 2; i <= number/2; i++)
    {
      if (number % i == 0){//remember that if you found a divisor, it is not prime check
        numPrime = false;
      }
    }//if the number is prime, display it
  if (numPrime){//But check if you have to move to the next line or stay on the current line
    if (count % 10 == 0){
      System.out.print(number + " ");
    }
    else{
     System.out.print(number + " ");
    }
    count++;
    //remember to increase the count variable for prime numbers 
  }
  number++;
  //and don't forget, prime or not, we increase the number variable
  //by 1 each time
}


    //Create a loop that runs until the count reaches 50 check
    //start by assuming the number is prime check
    //remember that if you found a divisor, it is not prime check
    //if the number is prime, display it
    //But check if you have to move to the next line or 
    //stay on the current line
    //remember to increase the count variable for prime numbers 
    //and don't forget, prime or not, we increase the number variable 
    //by 1 each time



    
   
  }
}
